class user_credential:
    uri:str
    user_name:str
    password:str
    database:str