import os
from google import genai
from google.genai import types

def generate():
    # Use your API key directly or from env
    client = genai.Client(
        api_key="AIzaSyC3Wf0-wJAD0oBGBIkTnZg5fb_eujW8YPM"
    )

    model = "gemini-1.5-flash"  # Use an available model
    contents = [
        types.Content(
            role="user",
            parts=[types.Part.from_text(text="Hello chat, can you tell the capital of Greece?")]
        )
    ]

    config = types.GenerateContentConfig(
        temperature=1,
        top_p=0.95,
        top_k=40,
        max_output_tokens=1024,
        response_mime_type="text/plain",
    )

    response = client.models.generate_content(
        model=model,
        contents=contents,
        config=config,
    )

    print(response.text)

if __name__ == "__main__":
    generate()
