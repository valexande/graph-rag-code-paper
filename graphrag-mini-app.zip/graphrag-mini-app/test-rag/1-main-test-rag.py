from neo4j import GraphDatabase
import os
from neo4j_graphrag.retrievers import VectorRetriever
from neo4j_graphrag.embeddings.openai import OpenAIEmbeddings
from neo4j_graphrag.llm import OpenAILLM
from neo4j_graphrag.generation import GraphRAG

os.environ["OPENAI_API_KEY"] = "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"
# Demo database credentials
URI = "neo4j+s://demo.neo4jlabs.com"
AUTH = ("recommendations", "recommendations")
# Connect to Neo4j database
driver = GraphDatabase.driver(URI, auth=AUTH)

embedder = OpenAIEmbeddings(model="text-embedding-ada-002")
retriever = VectorRetriever(
    driver,
    index_name="moviePlotsEmbedding",
    embedder=embedder,
    return_properties=["title", "plot"],
)


# LLM
# Note: the OPENAI_API_KEY must be in the env vars
llm = OpenAILLM(model_name="gpt-4o", model_params={"temperature": 0})

# Initialize the RAG pipeline
rag = GraphRAG(retriever=retriever, llm=llm)

# Query the graph
query_text = "What movies are sad romances?"
response = rag.search(query_text=query_text, retriever_config={"top_k": 5})
print(response.answer)

#https://neo4j.com/blog/developer/get-started-graphrag-python-package/