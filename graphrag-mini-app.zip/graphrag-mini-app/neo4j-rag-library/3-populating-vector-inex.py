from neo4j import GraphDatabase
from neo4j_graphrag.embeddings import OpenAIEmbeddings
from neo4j_graphrag.indexes import upsert_vectors
from neo4j_graphrag.types import EntityType

NEO4J_URI = "neo4j://localhost:7687"
NEO4J_USERNAME = "neo4j"
NEO4J_PASSWORD = "6985Ale!!@"

# Connect to the Neo4j database
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))

# Create an Embedder object
embedder = OpenAIEmbeddings(
    model="text-embedding-3-large",
    api_key="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"
)

# Generate an embedding for some text
text = (
    "The son of Duke Leto Atreides and the Lady Jessica, Paul is the heir of House "
    "Atreides, an aristocratic family that rules the planet Caladan."
)
vector = embedder.embed_query(text)

# Upsert the vector
upsert_vectors(
    driver,
    ids=["1234"],
    embedding_property="vectorProperty",
    embeddings=[vector],
    entity_type=EntityType.NODE,
)
driver.close()