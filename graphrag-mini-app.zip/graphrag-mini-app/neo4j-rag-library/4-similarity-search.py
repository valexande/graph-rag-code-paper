from neo4j import GraphDatabase
from neo4j_graphrag.embeddings import OpenAIEmbeddings
from neo4j_graphrag.generation import GraphRAG
from neo4j_graphrag.llm import OpenAILLM
from neo4j_graphrag.retrievers import VectorRetriever

NEO4J_URI = "neo4j://localhost:7687"
NEO4J_USERNAME = "neo4j"
NEO4J_PASSWORD = "6985Ale!!@"
INDEX_NAME = "vector-index-name"

# Connect to the Neo4j database
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))

# Create an Embedder object
# Create an Embedder object
embedder = OpenAIEmbeddings(
    model="text-embedding-3-large",
    api_key="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"
)

# Initialize the retriever
retriever = VectorRetriever(driver, INDEX_NAME, embedder)

# Instantiate the LLM
llm = OpenAILLM(model_name="gpt-4o", model_params={"temperature": 0}, api_key="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")

# Instantiate the RAG pipeline
rag = GraphRAG(retriever=retriever, llm=llm)

# Query the graph
query_text = "Who is Lady Jessica?"
response = rag.search(query_text=query_text, retriever_config={"top_k": 5})
print(response.answer)
driver.close()