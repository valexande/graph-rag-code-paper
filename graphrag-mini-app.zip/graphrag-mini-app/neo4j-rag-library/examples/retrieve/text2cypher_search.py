"""The example leverages the Text2CypherRetriever to fetch some context.
It uses the OpenAILLM, hence the OPENAI_API_KEY needs to be set in the
environment for this example to run.
"""

import neo4j
from neo4j_graphrag.llm import OpenAILLM
from neo4j_graphrag.retrievers import Text2CypherRetriever

# Define database credentials
URI = "neo4j+s://demo.neo4jlabs.com"
AUTH = ("recommendations", "recommendations")
DATABASE = "recommendations"
OPENAI_API_KEY = "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"

# Create LLM object
llm = OpenAILLM(
    model_name="gpt-4o",
    api_key=OPENAI_API_KEY,  # ← Add this line
    model_params={"temperature": 0}
)

# (Optional) Specify your own Neo4j schema
neo4j_schema = """
Node properties:
Person {name: STRING, born: INTEGER}
Movie {tagline: STRING, title: STRING, released: INTEGER}
Relationship properties:
ACTED_IN {roles: LIST}
DIRECTED {}
REVIEWED {summary: STRING, rating: INTEGER}
The relationships:
(:Person)-[:ACTED_IN]->(:Movie)
(:Person)-[:DIRECTED]->(:Movie)
(:Person)-[:REVIEWED]->(:Movie)
"""

# (Optional) Provide user input/query pairs for the LLM to use as examples
examples = [
    "USER INPUT: 'Which actors starred in the Matrix?' QUERY: MATCH (p:Person)-[:ACTED_IN]->(m:Movie) WHERE m.title = 'The Matrix' RETURN p.name"
]

with neo4j.GraphDatabase.driver(URI, auth=AUTH) as driver:
    # Initialize the retriever
    retriever = Text2CypherRetriever(
        driver=driver,
        llm=llm,
        neo4j_schema=neo4j_schema,
        examples=examples,
        # optionally, you can also provide your own prompt
        # for the text2Cypher generation step
        # custom_prompt="",
        neo4j_database=DATABASE,
    )

    # Generate a Cypher query using the LLM, send it to the Neo4j database, and return the results
    query_text = "Which movies did Hugo Weaving star in?"
    print(retriever.search(query_text=query_text))
